"""Add reproducible marine labels without overwriting land-country matches.

Sources: VLIZ Marine Regions EEZ v12 and IHO Sea Areas v3.
STRtree is a spatial index: it narrows the candidate polygons before covers().
EEZ associations are not assertions of territorial sovereignty.
"""
from pathlib import Path
import json
import pandas as pd
from shapely.geometry import Point, shape
from shapely import STRtree, make_valid, prepare


def load_boundaries(path):
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    features = data['features']
    total = data.get('numberMatched', data.get('totalFeatures'))
    if isinstance(total, int):
        assert total == len(features), 'Incomplete boundary download'
    geometries = []
    for feature in features:
        geometry = shape(feature['geometry'])
        if not geometry.is_valid:
            geometry = make_valid(geometry)
        geometries.append(geometry)
    prepare(geometries)
    return features, geometries, STRtree(geometries)


def covering(point, geometries, tree):
    # query() gives bounding-box candidates; covers() performs the exact check.
    return [int(i) for i in tree.query(point) if geometries[i].covers(point)]


def add_marine_locations(events, boundary_dir='data/boundaries'):
    boundary_dir = Path(boundary_dir)
    print('Loading EEZ and sea-area polygons...', flush=True)
    eez, eez_shapes, eez_tree = load_boundaries(boundary_dir/'marine_eez.geojson')
    seas, sea_shapes, sea_tree = load_boundaries(boundary_dir/'marine_iho.geojson')
    results = []
    for position, row in enumerate(events.itertuples(index=False), start=1):
        point = Point(row.Longitude, row.Latitude)
        result = dict(location_label='', location_type='', eez_countries='',
                      eez_territories='', eez_mrgids='', eez_source_names='',
                      sea_area='', sea_mrgids='', location_review=False)
        if row.country_match_status == 'matched':
            result.update(location_label=row.country_ne, location_type='land_country')
        elif row.country_match_status == 'multiple_matches':
            result.update(location_label='Land boundary: '+str(row.country_candidates),
                          location_type='land_multiple', location_review=True)
        else:
            marine_hits = covering(point, eez_shapes, eez_tree)
            sea_hits = covering(point, sea_shapes, sea_tree)
            sea_names = sorted({seas[i]['properties']['name'] for i in sea_hits})
            result['sea_area'] = ' | '.join(sea_names)
            result['sea_mrgids'] = ' | '.join(str(seas[i]['properties']['mrgid']) for i in sorted(sea_hits))
            if marine_hits:
                countries, territories = set(), set()
                for i in marine_hits:
                    properties = eez[i]['properties']
                    for suffix in ['1', '2', '3']:
                        if properties.get('sovereign'+suffix):
                            countries.add(properties['sovereign'+suffix])
                        if properties.get('territory'+suffix):
                            territories.add(properties['territory'+suffix])
                country_text = ' / '.join(sorted(countries))
                result.update(eez_countries=' | '.join(sorted(countries)),
                              eez_territories=' | '.join(sorted(territories)),
                              eez_mrgids=' | '.join(str(eez[i]['properties']['mrgid']) for i in sorted(marine_hits)),
                              eez_source_names=' | '.join(sorted({eez[i]['properties']['geoname'] for i in marine_hits})))
                if len(countries) == 1:
                    result.update(location_label=country_text+' EEZ', location_type='eez_single')
                elif len(countries) > 1:
                    result.update(location_label=country_text+' EEZ (overlap)',
                                  location_type='eez_multiple', location_review=True)
                else:
                    result.update(location_label=result['eez_source_names'],
                                  location_type='eez_other', location_review=True)
            elif sea_names:
                result.update(location_label=' / '.join(sea_names),
                              location_type='sea_area' if len(sea_names)==1 else 'sea_boundary',
                              location_review=len(sea_names)>1)
            else:
                # Do not call an inland/coastal gap an ocean or assign a nearest country.
                result.update(location_label=f'Boundary review ({row.Latitude:.3f}, {row.Longitude:.3f})',
                              location_type='boundary_review', location_review=True)
        results.append(result)
        if position % 5000 == 0:
            print(f'Marine labeling: {position:,}/{len(events):,} records', flush=True)
    added = pd.DataFrame(results, index=events.index)
    output = events.drop(columns=list(added.columns), errors='ignore').join(added)
    assert output['location_label'].notna().all()
    assert output['location_label'].str.len().gt(0).all()
    assert not output['location_label'].str.contains('unmatched', case=False).any()
    assert len(output) == len(events)
    return refine_land_gaps(output, boundary_dir)


def refine_land_gaps(events, boundary_dir='data/boundaries'):
    """Check remaining gaps against finer land polygons, without nearest-country assignment."""
    features, geometries, tree = load_boundaries(Path(boundary_dir)/'world_countries_10m.geojson')
    events = events.copy()
    if 'refined_land_source' not in events:
        events['refined_land_source'] = ''
    for index in events.index[events.location_type == 'boundary_review']:
        point = Point(events.loc[index,'Longitude'], events.loc[index,'Latitude'])
        hits = covering(point, geometries, tree)
        names = sorted({features[i]['properties']['country_ne'] for i in hits})
        if names:
            events.loc[index,'location_label'] = ' / '.join(names)
            events.loc[index,'location_type'] = 'land_refined_10m' if len(names)==1 else 'land_multiple_10m'
            events.loc[index,'location_review'] = len(names)>1
            events.loc[index,'refined_land_source'] = 'Natural Earth 5.1.2; ne_10m_admin_0_countries'
    return events


def save_location_summaries(events, folder, prefix):
    folder = Path(folder)
    summary = events.groupby(['location_type', 'location_label']).size().rename('event_count').reset_index()
    summary = summary.sort_values(['event_count','location_label'], ascending=[False,True])
    assert summary.event_count.sum() == len(events)
    summary.to_csv(folder/f'{prefix}_location_totals.csv', index=False, encoding='utf-8-sig')
    events.loc[events.location_review].to_csv(folder/f'{prefix}_location_review.csv', index=False, encoding='utf-8-sig')
    annual = events.groupby(['location_type','location_label','year']).size().rename('event_count').reset_index()
    annual.to_csv(folder/f'{prefix}_location_year_counts.csv', index=False, encoding='utf-8-sig')
    return summary


def plot_location_summary(events, folder, prefix, period):
    import matplotlib.pyplot as plt
    summary = save_location_summaries(events, folder, prefix)
    top = summary.head(20).iloc[::-1]
    palette = {'land_country':'#4777a8','land_refined_10m':'#4777a8','eez_single':'#29a3a3','eez_multiple':'#ca8045',
               'sea_area':'#8064a2','sea_boundary':'#a88ac7','boundary_review':'#9d9d9d'}
    fig, ax = plt.subplots(figsize=(14,10))
    ax.barh(top.location_label, top.event_count,
            color=[palette.get(s,'#9d9d9d') for s in top.location_type])
    ax.set_xlabel('Catalog event count')
    ax.set_title(f'Land countries, EEZ associations and sea areas | {period}')
    ax.grid(axis='x',alpha=.2)
    fig.text(.02,.015,'Land and EEZ categories are separate. Overlaps are counted once as a combined category.\nEEZ labels indicate source associations, not territorial sovereignty. Sources: Natural Earth; VLIZ EEZ v12; IHO v3.',fontsize=9)
    fig.tight_layout(rect=[0,.06,1,1])
    fig.savefig(Path(folder)/f'{prefix}_location_counts.png',dpi=220,bbox_inches='tight')
    plt.close(fig)
    return summary
