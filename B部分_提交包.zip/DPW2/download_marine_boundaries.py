"""Download official Marine Regions polygons for reproducible local matching.

Run from DPW2. Full source polygons are cached locally and are not bundled
in the submission archive; the provider requests links to its official service.
"""
from pathlib import Path
import hashlib
import json
import subprocess
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
BASE = 'https://geo.vliz.be/geoserver/MarineRegions/wfs'
LAYERS = {'eez': 'EEZ v12 (2023)', 'iho': 'IHO Sea Areas v3 (2018)'}


def download():
    metadata = {'provider':'Flanders Marine Institute (VLIZ), Marine Regions',
                'source':'https://www.marineregions.org/downloads.php',
                'service_documentation':'https://www.marineregions.org/webservices.php',
                'license':'CC BY; https://www.marineregions.org/disclaimer.php',
                'consulted_utc':datetime.now(timezone.utc).isoformat(),
                'method':'Static source boundaries applied to event coordinates; not historical boundaries.',
                'layers':{}}
    folder = ROOT/'data/boundaries'
    folder.mkdir(parents=True, exist_ok=True)
    for layer, title in LAYERS.items():
        url = (BASE+'?service=WFS&version=1.0.0&request=GetFeature'
               +'&typeName=MarineRegions:'+layer+'&outputFormat=application/json&srsName=EPSG:4326')
        path = folder/f'marine_{layer}.geojson'
        if not path.exists():
            temporary = path.with_suffix('.download')
            # curl uses the system TLS certificate store and supports gzip.
            subprocess.run(['curl','--fail','--location','--compressed','--retry','2',
                            '--max-time','1800',url,'--output',str(temporary)],check=True)
            json.loads(temporary.read_text(encoding='utf-8'))
            temporary.replace(path)
        raw = path.read_bytes()
        data = json.loads(raw)
        count = len(data['features'])
        expected = data.get('numberMatched',data.get('totalFeatures'))
        if isinstance(expected,int):
            assert expected == count, 'Incomplete feature collection'
        metadata['layers'][layer] = {'title':title,'url':url,'features':count,
                                    'sha256':hashlib.sha256(raw).hexdigest(),
                                    'crs':data.get('crs'),'server_timestamp':data.get('timeStamp')}
        print(title, count, 'features')
    (ROOT/'data/metadata/marine_boundaries_sources.json').write_text(
        json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    return metadata


if __name__ == '__main__':
    download()
